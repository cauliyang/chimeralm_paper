ChimeraLM: a language model enables accurate structural variant detection in
whole-genome amplified long-read sequencing -- LaTeX source, second revision
(NAR-00644-Met-K-2026.R1)

No text was changed in this revision (see point-by-point response); the only
change is the replaced Figure 3. The manuscript therefore carries no red
revision marks, and the marked and clean versions are the same file.

Files
  sn-article.tex     manuscript
  clean.bib, nar.bst references and Nucleic Acids Research BibTeX style (CTAN)
  sn-jnl.cls         document class
  main_figures/      Figures 1-4 (PDF); Figure 3 replaced in this revision
  sn-article.bbl     pre-generated bibliography (compiles without BibTeX)
  supplementary.aux  label file of the Supplementary Data PDF, read by the xr
                     package so "Supplementary Figure S1..S7 / Table S1" resolve.

Build:  latexmk -pdf sn-article.tex
