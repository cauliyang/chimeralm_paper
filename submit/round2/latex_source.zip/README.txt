ChimeraLM: a language model enables accurate structural variant detection in
whole-genome amplified long-read sequencing -- LaTeX source, second revision
(NAR-00644-Met-K-2026.R1)

Files
  sn-article.tex        MARKED manuscript (revised text in red via \chg{...})
  sn-article-clean.tex  CLEAN manuscript (identical source, \revisedtextfalse)
  clean.bib, nar.bst    references and Nucleic Acids Research BibTeX style (CTAN)
  sn-jnl.cls            document class
  main_figures/         Figures 1-4 (PDF). Figure 3 replaced in this revision
                        (panels b-e re-exported; see point-by-point response, R2).
  *.bbl                 pre-generated bibliographies (compile without BibTeX)
  supplementary.aux     label file of the Supplementary Data PDF, read by the xr
                        package so "Supplementary Figure S1..S7 / Table S1" resolve.

Build:  latexmk -pdf sn-article.tex ; latexmk -pdf sn-article-clean.tex
