ChimeraLM: a language model enables accurate structural variant detection in
whole-genome amplified long-read sequencing -- LaTeX source, second revision
(NAR-00644-Met-K-2026.R1)

Changes in this revision (see point-by-point response): Figure 3 replaced,
Figure 1 supplied as an editable vector PDF, back-matter headings reordered per
the NAR author checklist. No change to the scientific text, hence no red marks;
the marked and clean versions are the same file.

Files
  sn-article.tex     manuscript
  clean.bib, nar.bst references and Nucleic Acids Research BibTeX style (CTAN)
  sn-jnl.cls         document class
  main_figures/      Figures 1-4 as editable vector PDFs with live text.
                     Figure 1 embeds its illustration icons as bitmaps.
  sn-article.bbl     pre-generated bibliography (compiles without BibTeX)
  supplementary.aux  label file of the Supplementary Data PDF, read by the xr
                     package so "Supplementary Figure S1..S7 / Table S1" resolve.

Build:  latexmk -pdf sn-article.tex
