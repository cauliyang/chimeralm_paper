ChimeraLM: a language model enables accurate structural variant detection in
whole-genome amplified long-read sequencing -- LaTeX source (NAR-00644-Met-K-2026.R1)

Files
  sn-article.tex      main manuscript (revised text marked in red via \chg{...};
                      set \revisedtextfalse in the preamble for a clean copy)
  supplementary.tex   Supplementary Data (table S1, figures S1-S7, abbreviations)
  clean.bib           references; nar.bst = Nucleic Acids Research BibTeX style (CTAN)
  sn-jnl.cls          document class
  figures/final_figures/  main figures (figure1-4) and supplementary figures
  *.bbl, supplementary.aux  pre-generated so the package compiles without BibTeX

Build order (the main text cross-references the supplement through the xr package,
so the supplement must be compiled first):
  latexmk -pdf supplementary.tex
  latexmk -pdf sn-article.tex
