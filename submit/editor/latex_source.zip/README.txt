ChimeraLM: a language model enables accurate structural variant detection in
whole-genome amplified long-read sequencing -- LaTeX source (NAR-00644-Met-K-2026.R1)

Files
  sn-article.tex     main manuscript (revised text marked in red via \chg{...};
                     set \revisedtextfalse in the preamble for a clean copy)
  clean.bib          references; nar.bst = Nucleic Acids Research BibTeX style (CTAN)
  sn-jnl.cls         document class
  main_figures/      Figure 1 (figure1.tiff, 300 dpi) and Figures 2-4 (PDF).
                     figure1.pdf is a lossless (Flate) wrapper of figure1.tiff,
                     included only because pdfLaTeX cannot read TIFF directly.
  sn-article.bbl     pre-generated bibliography (compiles without running BibTeX)
  supplementary.aux  label file of the Supplementary Data PDF; read by the xr
                     package so that "Supplementary Figure S1..S7 / Table S1"
                     resolve in the main text. Keep it next to sn-article.tex.

Build:  latexmk -pdf sn-article.tex          (or: pdflatex x3)
